#include <iostream>
#include <vector>
using namespace std;

void swap(int &a, int &b){
    int temp = a;
    a = b;
    b = temp;
}

int pivot(vector<int> &arr, int left, int right){
    int key = arr[right];
    int start = left;
    for(int i = left; i < right; i++){
        if(arr[i] <= key){
            swap(arr[i],arr[start++]);
        }
    }
    swap(arr[right], arr[start]);
    return start;
}

void _quick_sort(vector<int> &arr, int left, int right){
    if(left < right){
        int p = pivot(arr, left, right);
        _quick_sort(arr, left, p-1);
        _quick_sort(arr, p+1, right);
    }
}

void quickSort(vector<int> &arr){
    int left = 0;
    int right = arr.size() - 1;
    _quick_sort(arr, left, right);
}

int main(int agrc, char **argv){
    int N;
    cin >> N;
    vector<int> arr(N);
    for(int i = 0; i < N; i++)
        cin >> arr[i];
    quickSort(arr);
    for(int i = 0; i < N - 1; i++){
        if(arr[i] == arr[i+1]){
            cout << arr[i];
            return 0;
        }
    }
    return 0;
}

