#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    long long N;
    int i;
    cin >> N >> i;
    if(N & (1LL << i)){
        cout << "true";
    }else{
        cout << "false";
    }
    return 0;
}

