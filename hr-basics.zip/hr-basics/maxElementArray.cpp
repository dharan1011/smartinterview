#include<iostream>
using namespace std;

int max(int x, int y){
    return (x > y) ? x : y;
}
int main(){
    int N;
    cin >> N;
    int res = 1 << 31; // INT_MIN
    int x;
    for(int i = 0; i < N; i++){
        cin >> x;
        res = max(res, x);
    }
    cout << res << "\n";
}
