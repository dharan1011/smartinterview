#include <iostream>
#include <algorithm>
using namespace std;

int main(int agrc, char **argv){
    string s;
    cin >> s;
    int n = s.size();
    int start = 0;
    for(int i = 1; i < n; i++){
        while(s[start] == s[i] && i < n){
            start++;
            i++;
        }
        if(i != n){
            start = 0;
        }else{
            i--;
            break;
        }
    }
    cout << start;
    return 0;
}

