#include <iostream>
#include <cmath>
using namespace std;

bool check(int N, int d){
    int t_N = N;
    int res = 0;
    while(N){
        res += pow(N%10,d);
        N /= 10;
    }
    return (t_N == res);
}

int main(int agrc, char **argv){
    int N;
    cin >> N;
    int d = floor(log10(N)+1);
    if(check(N, d)){
        cout << "Yes";
    }else{
        cout << "No";
    }
    return 0;
}

