#include <iostream>
#include <string>
using namespace std;

int main(int agrc, char **argv){
    string str;
    cin >> str;
    str += " ";
    int c = 1;
    for(int i = 0; i < str.size() - 1; i++){
        if(str[i] == str[i+1]){
            c++;
        }else{
            cout << str[i] << c;
            c = 1;
        }
    }
    return 0;
}

