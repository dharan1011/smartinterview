#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int N, key;
    cin >> N >> key;
    vector<int> arr(N);
    for(int i = 0; i < N; i++){
        cin >> arr[i];
    }
    int i;
    for(i = 0; i < N; i += 2){
        if(arr[i] == key){
            break;
        }
        if(i+1<N && arr[i+1] == key){
            i++;
            break;
        }
    }
    if(i < N){
        cout << i;
    }else{
        cout << -1;
    }
    return 0;
}

