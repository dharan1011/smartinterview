#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    int x1 = 0;
    for(int i = 1; i <= 100; i++)
        x1 ^= i;
    int num;
    int x2 = 0;
    for(int i = 0; i < 99; i++){
        cin >> num;
        x2 ^= num;
    }
    cout << (x1 ^ x2);
    return 0;
}

