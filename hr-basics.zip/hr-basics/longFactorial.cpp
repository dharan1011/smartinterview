#include <iostream>
using namespace std;

int mul(int *arr, int x,int size){
    int c = 0;
    for(int i = 0; i < size; i++){
        int num = (arr[i] * x) + c;
        arr[i] = num % 10;
        c = num / 10;
    }
    while(c){
        arr[size] = c % 10;
        c /= 10;
        size++;
    }
    return size;
}

int main(int agrc, char **argv){
    int N;
    cin >> N;
    int res[150] = {0};
    int size = 1;
    res[0] = 1;
    for(int i = 2; i <= N; i++){
        size = mul(res,i, size);
    }
    for(int i = size-1; i >= 0; i--){
        cout << res[i];
    }
    return 0;
}

