#include <iostream>
#include <vector>
using namespace std;

bool bs(vector<int> &arr, int key)
{
    int low = 0;
    int high = arr.size() - 1;
    while(low <= high){
        int mid = (high + low) / 2;
        if(arr[mid] == key){
            return true;
        }
        if(arr[mid] > key){
            high = mid - 1;
        }else{
            low = mid + 1;
        }
    }
    return false;
}
int main(int agrc, char **argv){
    int N, key;
    cin >> N >> key;
    vector<int> arr(N);
    for(int i = 0; i < N; i++){
        cin >> arr[i];
    }
    if(bs(arr,key)){
        cout << "true";
    }else{
        cout << "false";
    }
    return 0;
}

