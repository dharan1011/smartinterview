#include <iostream>
using namespace std;

long long pow(int a, int b){
 long long res = 1LL;
 while(b){
     if(b&1){
         res *= a;
     }
     b >>= 1;
     a *= a;
 }
 return res;
}

int main(int agrc, char **argv){
    int N;
    cin >> N;
    int res = 0;
    for(int i = 1; i <= N; i++){
        res += pow(i,2);
    }
    cout << res;
    return 0;
}

