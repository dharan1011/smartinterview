#include<iostream>
#include<vector>

using namespace std;

void printRev(vector<long long> &arr, int i, int N){
    if(i == N){
        return;
    }
    printRev(arr, i+1, N);
    cout << arr[i] << " ";
}

int main(){
    int N;
    cin >> N;
    vector<long long> arr(N);
    for(int i = 0; i < N; i++)
        cin >> arr[i];
    printRev(arr,0,arr.size());
    return 0;
}
