#include <iostream>
using namespace std;

long long pow(int a, int b){
long long res = 1LL;
while(b){
    if(b&1){
      res *= a;
    }
    b >>= 1;
    a *= a;
}
return res;
}

bool check(int num){
int t_num = num;
int res = 0;
while(num){
    int x = num % 10;
    res += pow(x,3);
    num /= 10;
}
return (res == t_num);
}

int main() {
/* Enter your code here. Read input from STDIN. Print output to STDOUT */   
int N;
cin >> N;
if(check(N)){
    cout << "Yes";
}else{
    cout << "No";
}
return 0;
}
