#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    int N, M;
    cin >> N >> M;
    int z = 0, x;
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            cin >> x;
            if(x == 0) z++;
        }
    }
    if(z > (N*M)/2){
        cout << "Yes";
    }else{
        cout << "No";
    }
    return 0;
}

