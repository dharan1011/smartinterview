#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    int N, M;
    cin >> N >> M;
    int arr[N][M];
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            cin >> arr[i][j];    
        }
    }
    int tarr[M][N];
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            tarr[j][i] = arr[i][j]; 
        }
    }
    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            cout << tarr[i][j] << ' '; 
        }
        cout << '\n';
    }
    return 0;
}

