#include <iostream>
using namespace std;
int sum(int N){
    int res = 0;
    while(N){
        res += (N%10);
        N /= 10;
    }
    return res;
}
int main(int agrc, char **argv){
    int N;
    cin >> N;
    int ds = sum(N);
    if(N%ds){
        cout << "No";
    }else{
        cout << "Yes";
    }
    return 0;
}

