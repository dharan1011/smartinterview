#include <iostream>
#include <string>
#include <cstdio>
using namespace std;

int main(int agrc, char **argv){
    string num;
    cin >> num;
    int sum = 0;
    for(size_t i = 0; i < num.size(); i++){
        sum += (num[i] - '0');
    }
    cout << sum;
    return 0;
}

