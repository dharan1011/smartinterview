#include <iostream>
using namespace std;
typedef long long ll;

ll reverse(ll N){
    ll res = 0LL;
    while(N){
        res = (res * 10) + (N%10);
        N /= 10;
    }
    return res;
}
int main(int agrc, char **argv){
    ll N;
    cin >> N;
    bool neg = (N < 0);
    if(neg){
        N *= -1;
    }
    ll rev = reverse(N);
    if(neg){
        rev *= -1;
    }
    cout << rev;
    return 0;
}