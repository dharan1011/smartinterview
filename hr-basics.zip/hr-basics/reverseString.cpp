#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    string s;
    cin >> s;
    int low = 0;
    int high = s.size() - 1;
    while(low < high){
        swap(s[low++],s[high--]);
    }
    cout << s;
    return 0;
}
