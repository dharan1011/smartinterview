#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    int N, M;
    cin >> N >> M;
    int arr[N][M];
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            cin >> arr[i][j];
        }
    }
    for(int j = 0; j < M; j++){
        int sum = 0;
        for(int i = 0; i < N; i++){
            sum += arr[i][j];
        }
        cout << sum << '\n';
    }
    return 0;
}

