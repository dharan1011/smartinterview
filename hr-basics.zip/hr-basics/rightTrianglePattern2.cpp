#include <iostream>
using namespace std;

int main(int agrc, char **argv){
    int N;
    cin >> N;
    int base = N - 1;
    for(int i = 1; i <= N; i++){
        int tb = base;
        int c = i;
        for(int j = 1; j <= i; j++){
            cout << c  << ' ';
            c += tb;
            tb--;
        }
        cout << '\n';
    }
    return 0;
}

